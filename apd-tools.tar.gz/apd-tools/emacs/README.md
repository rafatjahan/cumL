ACPI Source Language (ASL) Syntax Highlighting for emacs
========================================================

# Install

```sh
cp asl-mode.el $HOME/.emacs.d/
```

Then restart emacs.
